#ifndef ADMINWINDOW_ADMINPWD_H
#define ADMINWINDOW_ADMINPWD_H

#include <QDialog>
#include "manager.h"

namespace Ui {
class adminwindow_adminpwd;
}

/**
 * @brief The admin change admin password window
 * @author Yue Zhao
 */
class adminwindow_adminpwd : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow_adminpwd(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow_adminpwd();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button for changing the password of admin
     * the function will get a old password an a new password from the input on
     * the window. if the old Password is correct, will change the password
     */
    void on_pushButton_change_clicked();

signals:
    void backadmin();

private:
    Ui::adminwindow_adminpwd *ui;
    Manager* m;
};

#endif // ADMINWINDOW_ADMINPWD_H
