#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <QMessageBox>

adminwindow::adminwindow(QWidget* parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow::~adminwindow()
{
    delete ui;
}

void adminwindow::on_pushButton_login_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();
    std::string user = username.toUtf8().constData();
    std::string pwd = password.toUtf8().constData();
    if(this->m->loginAdmin(user, pwd)){
        admin_main = new adminwindow_main(this, m);
        this->hide();
        admin_main->show();
        connect(admin_main, SIGNAL(backsignal()), SIGNAL(backsignal()));
    }
    else{
        QMessageBox::warning(this,"Login","Username or Password Incorrect");
    }
}


void adminwindow::on_pushButton_back_clicked()
{
    emit backsignal();
    this->close();
}
