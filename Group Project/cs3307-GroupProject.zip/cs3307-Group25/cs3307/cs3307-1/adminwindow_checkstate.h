#ifndef ADMINWINDOW_CHECKSTATE_H
#define ADMINWINDOW_CHECKSTATE_H

#include <QDialog>
#include "manager.h"

namespace Ui {
class adminwindow_checkstate;
}

/**
 * @brief The admin check state window
 * @author Yue Zhao
 */
class adminwindow_checkstate : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow_checkstate(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow_checkstate();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button for checking the locker state
     * the function will get the input which is a locke id and show the state
     */
    void on_pushButton_check_clicked();

signals:
    void backadmin();

private:
    Ui::adminwindow_checkstate *ui;
    Manager* m;
};

#endif // ADMINWINDOW_CHECKSTATE_H
