#ifndef DROPIN_H
#define DROPIN_H

#include <string>

/**
 * @brief An object class
 * An object class to get information for Dropin object
 *
 * @author Yue Zhao
*/
class Dropin
{
public:
    /**
     * @brief A constructor.
     * Create a Dropin object
     */
    Dropin();

    /**
     * @brief A constructor with parameter
     * Create a Dropin object with two parameters name and phone number
     * @param addressee's name
     * @param addressee's phone number
     */
    void init(std::string name, std::string phonenum);

    /**
     * @brief get addressee's Name
     * get the name of addressee
     * @return addressee's name
     */
    std::string getName();

    /**
     * @brief get addressee's phone number
     * get the phone number of addressee
     * @return addressee's phone number
     */
    std::string getPhoneNum();

private:
    std::string name, phonenum;
};

#endif // DROPIN_H
