#ifndef ADMINWINDOW_DRIVER_H
#define ADMINWINDOW_DRIVER_H

#include <QDialog>
#include "adminwindow_driver_add.h"
#include "adminwindow_driver_delete.h"
#include "manager.h"

namespace Ui {
class adminwindow_driver;
}

/**
 * @brief The admin modify driver window
 * @author Yue Zhao
 */
class adminwindow_driver : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow_driver(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow_driver();

private slots:

    /**
     * @brief reshow the window
     */
    void reshow();

    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button go to add driver window
     */
    void on_pushButton_add_clicked();

    /**
     * @brief a button go to delete driver window
     */
    void on_pushButton_delete_clicked();

signals:
    void backadmin();

private:
    Ui::adminwindow_driver *ui;
    adminwindow_driver_add *add_driver;
    adminwindow_driver_delete *delete_driver;
    Manager* m;
};

#endif // ADMINWINDOW_DRIVER_H
