#include "administrator.h"

Administrator::Administrator()
{

}

void Administrator::init(std::string username, std::string pwd){
    this->username = username;
    this->password = pwd;
}

std::string Administrator::getUsername(){
    return this->username;
}

std::string Administrator::getPassword(){
    return this->password;
}

void Administrator::setPassword(std::string newpwd){
    this->password = newpwd;
}
