#ifndef PASSWORD_H_
#define PASSWORD_H_

#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sstream>

/**
 * @brief This is a header file for password class
 * @details The class as a object, can create a random 6-digit password and compare to other password
 * @author Yue Zhao
 */
class Password{

private:

	//create the private variable
	int password;


public:

   /**
    * @brief Create a random 6 digit password for the locker
    * @details This function uses the random method to create a 6 digit integer value password
    */
	void createNewPassword();

   /**
    * @brief Compare the given password with its current password
    * @details This function is a boolean type function that returns true if the two passwords are the same
    * returns false if the two password is not the same
    * @param p is a Password type locker password
    */
	bool compare(Password p);

   /**
    * @brief Password get function
    * @details This function gives the user the password
    * @return password which is its password
    */
	int getPassword();

   /**
    * @brief Set password by given input
    * @details This function allows the user to change locker password to the new one,
    * if there is an invalid input password, then an error will be catched
    * @param pw is an integer type locker password that will be set to the locker
    */
	void setPassword(int pw);

};




#endif /* PASSWORD_H_ */
