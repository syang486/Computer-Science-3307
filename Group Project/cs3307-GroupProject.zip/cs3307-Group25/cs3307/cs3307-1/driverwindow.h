#ifndef DRIVERWINDOW_H
#define DRIVERWINDOW_H

#include <QDialog>
#include <QMainWindow>
#include <QPushButton>
#include "driverwindow_dropin.h"
#include "manager.h"

namespace Ui {
class driverwindow;
}

/**
 * @brief The driver login window
 * @author Yue Zhao
 */
class driverwindow : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief driver login window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit driverwindow(QWidget *parent = nullptr, Manager* m = nullptr);
    ~driverwindow();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button for loging in the driver system
     * it will show the driver main window if the input is correct
     */
    void on_pushButton_login_clicked();

signals:
    void backsignal();

private:
    Ui::driverwindow *ui;
    driverwindow_dropin *dropin;
    Manager* m;
};

#endif // DRIVERWINDOW_H
