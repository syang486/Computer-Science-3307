#include "dropin.h"

Dropin::Dropin()
{

}

void Dropin::init(std::string name, std::string phonenum){
    this->name = name;
    this->phonenum = phonenum;
}

std::string Dropin::getName(){
    return this->name;
}

std::string Dropin::getPhoneNum(){
    return this->phonenum;
}
