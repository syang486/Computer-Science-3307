#include "addresseewindow.h"
#include "ui_addresseewindow.h"
#include <QMessageBox>

addresseewindow::addresseewindow(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::addresseewindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Addressee");
    this->m = m;
}

addresseewindow::~addresseewindow()
{
    delete ui;
}

void addresseewindow::on_pushButton_back_clicked()
{
    emit backsignal();
    this->close();
}

void addresseewindow::on_pushButton_pickup_clicked()
{
    QString lockerid = ui->lineEdit_lockerid->text();
    QString password = ui->lineEdit_password->text();
    std::string id_s = lockerid.toUtf8().constData();
    std::string pwd_s = password.toUtf8().constData();
    int id = std::stoi(id_s);
    int pwd = std::stoi(pwd_s);
    Pickup p;
    p.init(id, pwd);
    if(this->m->pickup(p)){
        QMessageBox::information(this, "Pickup", "Locker opened. Please pick up your parcel");
    }
    else{
        QMessageBox::warning(this, "Pickup", "Invalid Locker ID or password");
    }
}
