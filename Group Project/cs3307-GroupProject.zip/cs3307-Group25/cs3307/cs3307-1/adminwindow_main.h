#ifndef ADMINWINDOW_MAIN_H
#define ADMINWINDOW_MAIN_H

#include <QDialog>
#include "adminwindow_changestate.h"
#include "adminwindow_open.h"
#include "adminwindow_adminpwd.h"
#include "adminwindow_driver.h"
#include "adminwindow_checkstate.h"
#include "manager.h"

namespace Ui {
class adminwindow_main;
}

/**
 * @brief The admin main window
 * @author Yue Zhao
 */
class adminwindow_main : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow_main(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow_main();

private slots:
    /**
     * @brief reshow this window after a signal call
     */
    void reshow();

    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button go to change state window
     */
    void on_pushButton_change_state_clicked();

    /**
     * @brief a button go to open locker window
     */
    void on_pushButton_open_clicked();

    /**
     * @brief a button go to change admin password window
     */
    void on_pushButton_admin_pwd_clicked();

    /**
     * @brief a button go to modify driver window
     */
    void on_pushButton_driver_clicked();

    /**
     * @brief a button go to update state window
     */
    void on_pushButton_update_clicked();

    /**
     * @brief a button go to check locker state window
     */
    void on_pushButton_check_clicked();

signals:
    void backsignal();

private:
    Ui::adminwindow_main *ui;
    adminwindow_changestate *changestate;
    adminwindow_open *open;
    adminwindow_adminpwd *adminpwd;
    adminwindow_driver *driver;
    adminwindow_checkstate *check;
    Manager* m;
};

#endif // ADMINWINDOW_MAIN_H
