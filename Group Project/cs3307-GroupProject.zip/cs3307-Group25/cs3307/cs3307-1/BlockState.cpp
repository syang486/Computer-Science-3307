#include <stdio.h>
#include "BlockState.h"
#include "LockerState.h"

BlockState::BlockState(){
    
}

std::string BlockState::getStateName(){
    return "block";
}

void BlockState::open(){
    throw"cannot open in this state";
}
void BlockState:: store(){
    throw"cannot store in the locker";
}
void BlockState:: lock(){
    throw "the locker is locked";
}
