#include "pickup.h"

Pickup::Pickup()
{

}

void Pickup::init(int id, int pwd){
    this->lockerID = id;
    this->password = pwd;
}

int Pickup::getLockerID(){
    return  this->lockerID;
}

int Pickup::getPassword(){
    return this->password;
}
