#include "EmptyState.h"
#include <iostream>
#include "EmptyState.h"
#include "LockerState.h"

EmptyState::EmptyState(){
}

std::string EmptyState::getStateName(){
    return "empty";
}
