/**
 *@brief the header file of block state
 *@details define the operation that cannot do in the block state
 *@author Zhiqi Bei (Group 25)
 */

#ifndef BlockState_h
#define BlockState_h
#include "LockerState.h"
#include <string>

/**
 *@brief define the class of block state
 *@details in the block state, the locker cannot open and store
 *@author Zhiqi Bei (Group 25)
 */
class BlockState;

/**
 *@brief define the constructor for the class
 *@details BlockState is inherit from the Lockerstate
 */
class BlockState: public LockerState{
public:
    /**
     *@brief define the constructor for the class
     *@details define the constructor for BlockState
     */
    BlockState();
    /**
     *@brief define a getter method of the state name
     *@details get the state name of the current state
     */
    virtual std::string getStateName();
    /**
     *@brief define an open method for the locker in the block state
     *@details the locker cannot open in the full state
     */
    virtual void open();
    /**
     *@brief define an store method for the locker in the block state
     *@details the locker cannot store anything in the block state
     */
    virtual void store();
    /**
     *@brief define an lock method for the locker in the block state
     *@details the locker cannot lock anything in the block state
     */
    virtual void lock();
};

#endif /* BlockState_h */
