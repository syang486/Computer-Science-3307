#include "adminwindow_open.h"
#include "ui_adminwindow_open.h"
#include <QMessageBox>

adminwindow_open::adminwindow_open(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_open)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_open::~adminwindow_open()
{
    delete ui;
}

void adminwindow_open::on_pushButton_back_clicked()
{
    emit backadmin();
    this->close();
}

void adminwindow_open::on_pushButton_open_clicked()
{
    QString lockerid = ui->lineEdit_lockerid->text();
    std::string id = lockerid.toUtf8().constData();
    if(this->m->open(std::stoi(id))){
        QMessageBox::information(this, "Open Locker", "Locker Opened");
    }
    else{
        QMessageBox::warning(this, "Open Locker", "Invalid Locker ID");
    }
}
