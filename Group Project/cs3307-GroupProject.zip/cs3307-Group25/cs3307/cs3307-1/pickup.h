#ifndef PICKUP_H
#define PICKUP_H

#include <string>

/**
 * @brief An object class
 * An object class to get information for Pickup object
 *
 * @author Shulan Yang
*/
class Pickup
{
public:
    /**
     * @brief A constructor.
     * Create a Pickup class
     */
    Pickup();
    
    /**
     * @brief A constructor with parameter
     * Create a Pickup object with two parameters locker ID and inputted password
     * @param id a locker ID
     * @param pwd a inputted password
     */
    void init(int id, int pwd);
    
    /**
     * @brief A method function
     * Method of getting a Locker ID inputted by customers
     * @return the locker ID
     */
    int getLockerID();
    
    /**
    * @brief A method function
    * Method of getting a password inputted by customers
    * @return the password
    */
    int getPassword();

private:
    /**
     * @brief A private variable.
     * Variable that store the inputted password
     */
    int password;
    
    /**
     * @brief A private variable.
     * Variable that store the inputted locker ID
     */
    int lockerID;
};

#endif // PICKUP_H
