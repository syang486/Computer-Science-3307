#include "adminwindow_adminpwd.h"
#include "ui_adminwindow_adminpwd.h"
#include <QMessageBox>

adminwindow_adminpwd::adminwindow_adminpwd(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_adminpwd)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_adminpwd::~adminwindow_adminpwd()
{
    delete ui;
}

void adminwindow_adminpwd::on_pushButton_back_clicked()
{
    emit backadmin();
    this->close();
}

void adminwindow_adminpwd::on_pushButton_change_clicked()
{
    QString oldpwd = ui->lineEdit_oldpwd->text();
    QString newpwd = ui->lineEdit_newpwd->text();
    std::string old_pwd = oldpwd.toUtf8().constData();
    std::string new_pwd = newpwd.toUtf8().constData();
    if(this->m->changeAdminPwd(old_pwd, new_pwd)){
        QMessageBox::information(this, "Change Admin Password", "Password changed");
    }
    else{
        QMessageBox::warning(this, "Change Admin Password", "Wrong old password");
    }
}
