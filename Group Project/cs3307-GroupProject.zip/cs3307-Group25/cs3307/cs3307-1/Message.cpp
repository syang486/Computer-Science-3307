#include <iostream>
#include <string>
#include <memory>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Message.h"

using namespace std;


bool Message::sendMessage(std::string name, std::string phonenum, int lockerId, int pwd){
    
    std::string account_sid = "ACc6a3de80c578ffd64cbb2b668259b293";
    std::string auth_token = "216b1d647139733584cdbc93c585bbf5";
    std::string message;
    std::string from_number = "+19494075189";
    std::string to_number;
    std::string picture_url;
    bool verbose = false;
    //opterr = 0;
    std::string response;
    auto twilio = std::make_shared<twilio::Twilio>(
       account_sid,
       auth_token
    );
    
    to_number = "+1" + phonenum;
    
    message = "Hi, "+ name +". Your parcel is in locker " + to_string(lockerId) + " and the password is " + to_string(pwd) + ".";


    bool message_success = twilio->send_message(
           to_number,
           from_number,
           message,
           response,
           picture_url,
           verbose
    );

    // Report success or failure
    if (!message_success) {
           cout << "Message send failed, phone number is invalid." << endl;
           return false;
                   
    } else{
           cout << "SMS sent successfully!" << endl;
           return true;
    }
}
