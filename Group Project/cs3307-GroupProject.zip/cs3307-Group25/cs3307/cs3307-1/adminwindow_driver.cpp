#include "adminwindow_driver.h"
#include "ui_adminwindow_driver.h"

adminwindow_driver::adminwindow_driver(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_driver)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_driver::~adminwindow_driver()
{
    delete ui;
}

void adminwindow_driver::reshow(){
    this->show();
}

void adminwindow_driver::on_pushButton_back_clicked()
{
    emit backadmin();
    this->close();
}

void adminwindow_driver::on_pushButton_add_clicked()
{
    add_driver = new adminwindow_driver_add(this, m);
    add_driver->show();
    this->hide();
    connect(add_driver, SIGNAL(backdriver()), this, SLOT(reshow()));
}

void adminwindow_driver::on_pushButton_delete_clicked()
{
    delete_driver = new adminwindow_driver_delete(this, m);
    delete_driver->show();
    this->hide();
    connect(delete_driver, SIGNAL(backdriver()), this, SLOT(reshow()));
}
