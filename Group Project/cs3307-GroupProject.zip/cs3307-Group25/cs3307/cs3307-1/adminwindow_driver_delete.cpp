#include "adminwindow_driver_delete.h"
#include "ui_adminwindow_driver_delete.h"
#include <QMessageBox>

adminwindow_driver_delete::adminwindow_driver_delete(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_driver_delete)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_driver_delete::~adminwindow_driver_delete()
{
    delete ui;
}

void adminwindow_driver_delete::on_pushButton_back_clicked()
{
    emit backdriver();
    this->close();
}

void adminwindow_driver_delete::on_pushButton_delete_clicked()
{
    QString username = ui->lineEdit_username->text();
    std::string user = username.toUtf8().constData();
    if(this->m->deleteDriver(user)){
        QMessageBox::information(this, "Delete Driver", "Driver deleted");
    }
    else{
        QMessageBox::warning(this, "Delete Driver", "Driver does exist");
    }
}
