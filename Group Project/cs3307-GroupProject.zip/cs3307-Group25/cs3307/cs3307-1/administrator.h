/**
 *@brief this is the header file for administrator
 *@details A header file of administrator, and define the methods and variables used in Administrator.cpp
 *@author Zhiqi Bei (Group 25)
 */
#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include <string>

/**
 *@brief A class for administrator
 *@details this class contain the username, password and their getter, setter method
 */
class Administrator
{
public:
    Administrator();
    /**
     *@brief define the constructor of the class
     *@details this constructor initialize the username and pwd with the given parameters
     */
    void init(std::string username, std::string pwd);
    /**
     *@brief define the getter methof of the username
     *@details the getter method is getting the user name of the administrator,then return
     */
    std::string getUsername();
    /**
     *@brief define the getter methof of the password
     *@details the getter method is getting the password of the administrator, then return
     */
    std::string getPassword();
    /**
     *@brief define the setter methof of the password
     *@details the setter method is getting the password of the administrator using the given parameter, then return
     *@param[in] pwd the new password that need to be set
     */
    void setPassword(std::string newpwd);

private:
    std::string username, password;
};

#endif // ADMINISTRATOR_H
