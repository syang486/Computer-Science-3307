#include "adminwindow_checkstate.h"
#include "ui_adminwindow_checkstate.h"
#include <QMessageBox>

adminwindow_checkstate::adminwindow_checkstate(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_checkstate)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_checkstate::~adminwindow_checkstate()
{
    delete ui;
}

void adminwindow_checkstate::on_pushButton_back_clicked()
{
    emit backadmin();
    this->close();
}

void adminwindow_checkstate::on_pushButton_check_clicked()
{
    QString lockerid = ui->lineEdit_lockerid->text();
    std::string id = lockerid.toUtf8().constData();
    std::string state = this->m->check(std::stoi(id));
    QString s = QString::fromStdString(state);
    if(state.compare("Invalid Locker ID") == 0){
        QMessageBox::warning(this, "Check Locker State", "Invalid Locker ID");
    }
    else{
        QMessageBox::information(this, "Check Locker State", QString("Locker %1 state: %2").arg(lockerid).arg(s));
    }
}
