#ifndef ExpiredState_h
#define ExpiredState_h
#ifndef EXPIRED_STATE_H
#define EXPIRED_STATE_H
#include "LockerState.h"
#include <string>

/**
 * @brief A constructor class
 * A constructor class that initialize Expired State object
 * @author Shulan Yang
 */
class ExpiredState;

/**
 * @brief A constructor class
 * A constructor class which inherit LockerState class initializes Expired State object
 */
class ExpiredState: public LockerState{
public:

    /**
     * @brief A constructor method
     * A constructor class that initialize Expired State object
     */
    ExpiredState();
    
    /**
     * @brief A getting method
     * An override method of getting a state name
     * @return the state name string
     */
    virtual std::string getStateName();
    
    /**
     * @brief A open method
     * An override method of opening the locker
     */
    virtual void open();
    
    /**
     * @brief A store method
     * An override method of storing the parcel into the locker
     */
    virtual void store();
    
    /**
     * @brief A lock method
     * An override method of locking the locker
     */
    virtual void lock();
    
    /**
     * @brief An alarm method
     * An override method of alarming to the manager
     */
    virtual void alarm();
};

#endif

#endif /* ExpiredState_h */
