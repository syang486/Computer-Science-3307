#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QDialog>
#include <QMainWindow>
#include <QPushButton>
#include "adminwindow_main.h"
#include "manager.h"

namespace Ui {
class adminwindow;
}

/**
 * @brief The admin login window
 * @author Yue Zhao
 */
class adminwindow : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow();

private slots:
    /**
     * @brief a button for login admin system
     * if the input username and password correct, will show the admin main window
     */
    void on_pushButton_login_clicked();

    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

signals:
    void backsignal();
private:
    Ui::adminwindow *ui;
    adminwindow_main *admin_main;
    Manager* m;
};

#endif // ADMINWINDOW_H
