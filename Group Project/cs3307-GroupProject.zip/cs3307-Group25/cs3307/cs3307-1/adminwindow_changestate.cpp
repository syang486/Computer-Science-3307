#include "adminwindow_changestate.h"
#include "ui_adminwindow_changestate.h"
#include <QMessageBox>

adminwindow_changestate::adminwindow_changestate(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_changestate)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_changestate::~adminwindow_changestate()
{
    delete ui;
}

void adminwindow_changestate::on_pushButton_back_clicked()
{
    emit backadmin();
    this->close();
}

void adminwindow_changestate::on_pushButton_change_clicked()
{
    QString lockerid = ui->lineEdit_lockerid->text();
    QString newstate = ui->lineEdit_newstate->text();
    std::string id = lockerid.toUtf8().constData();
    std::string state = newstate.toUtf8().constData();
    if(this->m->setState(std::stoi(id), state)){
        QMessageBox::information(this, "Change Locker State", "State Changed");
    }
    else{
        QMessageBox::warning(this, "Change Locker State", "Invalid Locker ID or state name");
    }
}
