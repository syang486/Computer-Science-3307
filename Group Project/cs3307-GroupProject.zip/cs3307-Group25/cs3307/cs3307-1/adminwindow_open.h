#ifndef ADMINWINDOW_OPEN_H
#define ADMINWINDOW_OPEN_H

#include <QDialog>
#include "manager.h"

namespace Ui {
class adminwindow_open;
}

/**
 * @brief The admin open locker window
 * @author Yue Zhao
 */
class adminwindow_open : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow_open(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow_open();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button for opening a locker by Administrator
     */
    void on_pushButton_open_clicked();

signals:
    void backadmin();

private:
    Ui::adminwindow_open *ui;
    Manager* m;
};

#endif // ADMINWINDOW_OPEN_H
