#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Welcome");
    this->m = new Manager;
    this->m->init();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::reshow(){
    this->show();
}

void MainWindow::on_pushButton_addressee_clicked()
{
    addressee = new addresseewindow(this, m);
    addressee->show();
    this->hide();
    connect(addressee, SIGNAL(backsignal()), this, SLOT(reshow()));
}

void MainWindow::on_pushButton_admin_clicked()
{
    admin = new adminwindow(this, m);
    admin->show();
    this->hide();
    connect(admin, SIGNAL(backsignal()), this, SLOT(reshow()));
}

void MainWindow::on_pushButton_driver_clicked()
{
    driver = new driverwindow(this, m);
    driver->show();
    this->hide();
    connect(driver, SIGNAL(backsignal()), this, SLOT(reshow()));
}


void MainWindow::on_pushButton_exit_clicked()
{
    this->close();
}
