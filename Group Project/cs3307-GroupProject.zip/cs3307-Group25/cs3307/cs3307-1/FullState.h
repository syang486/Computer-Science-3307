/**
 *@brief header file of FullState.cpp
 *@details define the operation that cannot do in the full state
 *@author Zhiqi Bei (Group 25)
 */

#ifndef FullState_h
#define FullState_h
#include "LockerState.h"
#include <string>
class FullState;

/**
 *@brief the class of full state
 *@details Fullstate is inherit from the Lockerstate
 */
class FullState: public LockerState{
public:
   /**
    *@brief the constructor for the class
    *@details the constructor for the class
    */
    FullState();
     /**
      *@brief define a getter method of the state name
      *@details get the state name of the current state
      */
    virtual std::string getStateName();
    /**
     *@brief define an open method for the locker in the full state
     *@details the locker cannot open in the full state
     */
    virtual void open();
    /**
     *@brief define an store method for the locker in the full state
     *@details the locker cannot store anything in the full state
     */
    virtual void store();
};


#endif /* FullState_h */
