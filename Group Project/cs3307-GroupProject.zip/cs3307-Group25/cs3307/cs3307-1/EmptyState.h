
#ifndef EMPTY_STATE_H
#define EMPTY_STATE_H
#include "LockerState.h"
#include <string>

/**
 * @brief A constructor class
 * A constructor class that initialize Empty State
 * @author Shulan Yang
*/
class EmptyState;

/**
 * @brief A constructor class
 * A constructor class which inherit LockerState class initializes Empty State object
 * @author Shulan yang
*/
class EmptyState: public LockerState{
public:
    /**
     * @brief A constructor method
     * A constructor method which inherit LockerState class initializes Empty State object
     */
    EmptyState();
    /**
     * @brief A getting method
     * An override method of getting a state name
     * @return the state name string
     */
    virtual std::string getStateName();
    
};

#endif
