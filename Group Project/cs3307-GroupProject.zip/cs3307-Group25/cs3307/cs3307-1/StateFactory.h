#ifndef StateFactory_h
#define StateFactory_h
#include "LockerState.h"
#include "StateName.h"
#include <string>

class StateFactory;
/**
 *@brief this is a header file of StateFactory.cpp
 *@details this class create an state base on the given statname, and the locker only have empty, block, full and expried states, other given state will not accept by this class
 *@author Zhiqi Bei (Group 25)
 */
class StateFactory{
public:
    /**
     *@brief define the createState method
     *@details this method use to create state base on the given input state name
     *@param[in] statename the given statename that need to be create the associate state
     */
    LockerState * createState(std::string StateName);
};

#endif /* StateFactory_h */
