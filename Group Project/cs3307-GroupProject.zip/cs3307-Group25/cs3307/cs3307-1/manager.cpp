#include "manager.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

/*
 * @brief initialize the Manager
 * @details read 3 files which include information of lockers, drivers and admins
 * , then initialize the private variable in the class
 */
void Manager::init(){
    ifstream f_driver, f_admin, f_locker;
    this->numOfDriver=0;
    std::string part;
    f_driver.open("/Users/yuezhao/Desktop/data/driver.txt");
    if(!f_driver){
        f_driver.close();
    }
    while(f_driver){
        getline(f_driver, part);
        if(part == ""){
            break;
        }
        std::stringstream ss(part);
        std::string tmp;
        std::vector <std::string> tokens;
        while(std::getline(ss, tmp, ' ')){
            tokens.push_back(tmp);
        }
        Driver* d = new Driver;
        d->init(tokens[0], tokens[1]);
        this->listOfDriver[this->numOfDriver] = d;
        this->numOfDriver++;
    }
    f_driver.close();

    this->numOfLocker=0;
    f_locker.open("/Users/yuezhao/Desktop/data/locker.txt");
    if(!f_locker){
        f_locker.close();
    }
    while(f_locker){
        getline(f_locker, part);
        if(part == ""){
            break;
        }
        std::stringstream ss(part);
        std::string tmp;
        std::vector <std::string> tokens;
        while(std::getline(ss, tmp, ' ')){
            tokens.push_back(tmp);
        }
        Locker *l = new Locker;
        int id = stoi(tokens[0]);
        int pwd = stoi(tokens[1]);
        std::string state = tokens[2];
        int st = stoi(tokens[3]);
        l->init(id, pwd, state, st);
        this->listoflocker[this->numOfLocker] = l;
        this->numOfLocker++;
    }
    f_locker.close();

    f_admin.open("/Users/yuezhao/Desktop/data/admin.txt");
        if(!f_admin){
            f_admin.close();
        }
        getline(f_admin, part);
        std::stringstream ss(part);
        std::string tmp;
        std::vector <std::string> tokens;
        while(std::getline(ss, tmp, ' ')){
            tokens.push_back(tmp);
        }
        this->admin.init(tokens[0], tokens[1]);
        f_admin.close();
}

/*
 * @brief driver dropin a parcel
 * @details driver want to drop in a parcel, then will open a empty locker and send
 * message to addressee with the locker id and password
 * @param a Dropin object which include addressee's name and phone number
 */
std::string Manager::dropin(Dropin dropin){
    try{
        Locker* l = this->getEmpty();
        Message m;
        Password p;
        p.createNewPassword();
        if(!m.sendMessage(dropin.getName(), dropin.getPhoneNum(), l->getLockerID(), p.getPassword())){
            return "Invalid phone number";
        }
        l->getLockerState()->open();
        l->setLockerPassword(p.getPassword());
        STime t;
        t.startTime();
        l->setStartTime(t.getStartTime());
        l->setLockerState("full");
        this->printout_locker();
        return std::to_string(l->getLockerID());
    }
    catch(const char* msg){
        cerr << msg <<endl;
        return "No empty locker";
    }
}

/*
 * @brief pick up a parcel
 * @details the function will open the locker if the locker id and password in the
 * input parameter is correct
 * @param a Pickup object which include locker id and password
 */
bool Manager::pickup(Pickup pickup){
    if(pickup.getLockerID() > this->numOfLocker){
        return false;
    }
    else{
        if(this->listoflocker[pickup.getLockerID()-1]->getLockerPassword() == pickup.getPassword()){
            Locker* tmp = listoflocker[pickup.getLockerID()-1];
            this->setState(pickup.getLockerID(), "empty");
            tmp->getLockerState()->open();
            this->printout_locker();
            return true;
        }
        else{
            return false;
        }
    }
}

/*
 * @brief get a empty locker
 * @details the function will check the locker array to find a empty locker, then
 * return it
 * @return return a Locker object point with is empty
 */
Locker* Manager::getEmpty(){
    for(int i = 0; i < this->numOfLocker; i++){
        if(this->listoflocker[i]->getLockerState()->getStateName().compare("empty") == 0){
            return listoflocker[i];
        }
    }
    throw "No empty locker";
}

/*
 * @brief open the locker by id
 * @details open the locker and then return ture if can open, otherwise return false
 * @param locker id
 * @return return ture if the locker can open, otherwise return false
 */
bool Manager::open(int id){
    if(id <= this->numOfLocker){
        cout << "locker " << id << " is opened" << endl;
        return true;
    }
    else{
        cout << "locker " << id << " cannot open" << endl;
        return false;
    }
}

/*
 * @brief set the state by input
 * @details the fuction will change the locker state to the new state which in the
 * input
 * @param a locker id
 * @param a state name
 * @return true if change state success, otherwise false
 */
bool Manager::setState(int id, std::string newstate){
    if(id > this->numOfLocker){
        return false;
    }
    for(int i = 0; i < this->numOfLocker; i++){
        if(this->listoflocker[i]->getLockerID() == id){
            if(newstate.compare("empty") == 0){
                this->listoflocker[i]->setLockerState(newstate);
                this->listoflocker[i]->setStartTime(0);
                this->listoflocker[i]->setLockerPassword(0);
                this->printout_locker();
                return true;
            }
            else if(newstate.compare("full")==0 || newstate.compare("block")==0 || newstate.compare("expired")==0) {
                this->listoflocker[i]->setLockerState(newstate);
                this->printout_locker();
                return true;
            }
            return false;
        }
    }
    return false;
}

/*
 * @brief check a locker state
 * @details the function will return the state of the locker if exist
 * @param a locker id
 * @return the state name of locker
 */
std::string Manager::check(int id){
    if(id > this->numOfLocker){
        return "Invalid Locker ID";
    }
    else{
        return this->listoflocker[id-1]->getLockerState()->getStateName();
    }
}

/*
 * @brief update the state of lockers which stored over 7 days
 * @details the function will check all the locker and if the locker have stored
 * over 7 days, then will change the state to expired
 * @return true if the operation finished, otherwise return false
 */
std::string Manager::updateLocker(){
    std::string warning = "";
    for(int i = 0; i < this->numOfLocker; i++){
        if(this->listoflocker[i]->getStartTime() != 0){
            int st = this->listoflocker[i]->getStartTime();
            STime tmp;
            tmp.setStartTime(st);
            tmp.setStorageTime();
            if(tmp.getTime() > 7){
                this->listoflocker[i]->setLockerState("expired");
                warning = warning + std::to_string(this->listoflocker[i]->getLockerID()) + " ";
            }
        }
    }
    this->printout_locker();
    return warning;
}

/*
* @brief add a new driver
* @details the function will add a new driver in the array by the input username
* and password
* @param username of driver
* @param password of driver
* @return true if add success, otherwise false
*/
bool Manager::addDriver(std::string username, std::string pwd){
    for(int i = 0; i < this->numOfDriver; i++){
        if(this->listOfDriver[i]->getUsername().compare(username) == 0){
            return false;
        }
    }
    Driver* d = new Driver;
    d->init(username, pwd);
    this->listOfDriver[this->numOfDriver] = d;
    this->numOfDriver++;
    this->printout_driver();
    return true;
}

/*
* @brief delete a driver
* @details the function will delete a new driver in the array by the input username
* @param username of driver
* @return true if delete success, otherwise false
*/
bool Manager::deleteDriver(std::string username){
    int i = 0;
    while(i < this->numOfDriver){
        if(this->listOfDriver[i]->getUsername().compare(username) == 0){
            for(int j = i; j < this->numOfDriver-1; j++){
                this->listOfDriver[j] = this->listOfDriver[j+1];
            }
            this->numOfDriver--;
            this->printout_driver();
            return true;
        }
        i++;
    }
    return false;
}

/*
* @brief chaneg the password of administator
* @details the function will change the password of admin if the input old password
* is correct
* @param old password of admin
* @param new password of admin
* @return true if change success, otherwise false
*/
bool Manager::changeAdminPwd(std::string oldpwd, std::string newpwd){
    if(this->admin.getPassword().compare(oldpwd) == 0){
        this->admin.setPassword(newpwd);
        this->printout_admin();
        return true;
    }
    else{
        return false;
    }
}

/*
* @brief a admin want to log in the system
* @details the function will allow admin to log in the system if the username and
* password are correct
* @param username of admin
* @param password of admin
* @return true if login success, otherwise false
*/
bool Manager::loginAdmin(std::string username, std::string pwd){
    if(this->admin.getUsername().compare(username) == 0 && this->admin.getPassword().compare(pwd) == 0){
        return true;
    }
    else{
        return false;
    }
}

/*
* @brief a driver want to log in the system
* @details the function will allow driver to log in the system if the username and
* password are correct
* @param username of driver
* @param password of driver
* @return true if login success, otherwise false
*/
bool Manager::loginDriver(std::string username, std::string pwd){
    for(int i = 0; i < this->numOfDriver; i++){
        if(this->listOfDriver[i]->getUsername().compare(username) == 0){
            if(this->listOfDriver[i]->getPassword().compare(pwd) == 0){
                return true;
            }
            else{
                return false;
            }
        }
    }
    return false;
}

/*
* @brief print out the information of lockers
* @details the function will print out the new information of all lockers
*/
void Manager::printout_locker(){
    ofstream f_locker;
    f_locker.open("/Users/yuezhao/Desktop/data/locker.txt");
    if(!f_locker){
        f_locker.close();
    }
    for(int i = 0; i < this->numOfLocker; i++){
        string tmp = std::to_string(this->listoflocker[i]->getLockerID()) + " " + std::to_string(this->listoflocker[i]->getLockerPassword()) + " " + this->listoflocker[i]->getLockerState()->getStateName() + " " + std::to_string(this->listoflocker[i]->getStartTime()) + "\n";
        f_locker << tmp;
    }
    f_locker.close();
}

/*
* @brief print out the information of drivers
* @details the function will print out the new information of all drivers
*/
void Manager::printout_driver(){
    ofstream f_driver;
    f_driver.open("/Users/yuezhao/Desktop/data/driver.txt");
    if(!f_driver){
        f_driver.close();
    }
    for(int i = 0; i < this->numOfDriver; i++){
        string tmp = this->listOfDriver[i]->getUsername() + " " + this->listOfDriver[i]->getPassword() + "\n";
        f_driver << tmp;
    }
    f_driver.close();
}

/*
* @brief print out the information of drivers
* @details the function will print out the new information of all drivers
*/
void Manager::printout_admin(){
    ofstream f_admin;
    f_admin.open("/Users/yuezhao/Desktop/data/admin.txt");
    if(!f_admin){
        f_admin.close();
    }
    string tmp = this->admin.getUsername() + " " + this->admin.getPassword() + "\n";
    f_admin << tmp;
    f_admin.close();
}

