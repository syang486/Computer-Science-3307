#ifndef DRIVER_H
#define DRIVER_H

#include <string>

/**
 *@brief A class for driver
 *@details this class contain the username, password and their getter, setter method
 *
 * @author Yue Zhao
 */
class Driver
{
public:
    Driver();

    /**
     *@brief define the constructor of the class
     *@details this constructor initialize the username and pwd with the given parameters
     */
    void init(std::string username, std::string pwd);

    /**
     *@brief define the getter methof of the username
     *@details the getter method is getting the user name of the driver,then return
     *@return driver's username
     */
    std::string getUsername();

    /**
     * @brief get Password of driver
     * @details the getter method is getting the drivers's password
     * @return driver's password
     */
    std::string getPassword();

    /**
     * @brief set Password of driver
     * the set method will set the driver's password by input
     * @param new passwordßß
     */
    void setPassword(std::string newpwd);

private:
    std::string username, password;
};

#endif // DRIVER_H
