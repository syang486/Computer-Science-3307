#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include "adminwindow.h"
#include "driverwindow.h"
#include "addresseewindow.h"
#include "manager.h"

namespace Ui {

class MainWindow;
}

/**
 * @brief The MainWindow class is the main window of project
 * the main window will show 3 type of sytstem include addresssee, driver and administrator
 * @author Yue Zhao
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief Main Window constructor
     * @param parent
     */
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    /**
     * @brief reshow the window after a signal
     */
    void reshow();

    /**
     * @brief a button for getting in addressee system
     */
    void on_pushButton_addressee_clicked();

    /**
     * @brief a button for getting in Administrator system
     */
    void on_pushButton_admin_clicked();

    /**
     * @brief a button for getting in driver system
     */
    void on_pushButton_driver_clicked();

    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_exit_clicked();


private:
    Ui::MainWindow *ui;
    adminwindow *admin;
    driverwindow *driver;
    addresseewindow *addressee;
    Manager* m;
};

#endif // MAINWINDOW_H
