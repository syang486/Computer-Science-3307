#include "driverwindow.h"
#include "ui_driverwindow.h"
#include <QMessageBox>

driverwindow::driverwindow(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::driverwindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Driver");
    this->m = m;
}

driverwindow::~driverwindow()
{
    delete ui;
}

void driverwindow::on_pushButton_back_clicked()
{
    emit backsignal();
    this->close();
}

void driverwindow::on_pushButton_login_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();
    std::string user = username.toUtf8().constData();
    std::string pwd = password.toUtf8().constData();
    if(this->m->loginDriver(user, pwd)){
        dropin = new driverwindow_dropin(this, this->m);
        this->hide();
        dropin->show();
        connect(dropin, SIGNAL(backsignal()), SIGNAL(backsignal()));
    }
    else{
        QMessageBox::warning(this,"Login","Username or Password Incorrect");
    }
}
