#include "adminwindow_driver_add.h"
#include "ui_adminwindow_driver_add.h"
#include <QMessageBox>

adminwindow_driver_add::adminwindow_driver_add(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_driver_add)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_driver_add::~adminwindow_driver_add()
{
    delete ui;
}

void adminwindow_driver_add::on_pushButton_back_clicked()
{
    emit backdriver();
    this->close();
}

void adminwindow_driver_add::on_pushButton_add_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();
    std::string user = username.toUtf8().constData();
    std::string pwd = password.toUtf8().constData();
    if(this->m->addDriver(user, pwd)){
        QMessageBox::information(this, "Add Driver", "New Driver added");
    }
    else{
        QMessageBox::warning(this, "Add Driver", "username already exist");
    }
}
