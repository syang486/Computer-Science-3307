#ifndef ADDRESSEEWINDOW_H
#define ADDRESSEEWINDOW_H

#include <QDialog>
#include "manager.h"

namespace Ui {
class addresseewindow;
}

/**
 * @brief The addressee system window
 * @author Yue Zhao
 */
class addresseewindow : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief addressee window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit addresseewindow(QWidget *parent = nullptr, Manager* m = nullptr);
    ~addresseewindow();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button for picking up parcel
     * the button will open the locker if the input on the window is correct
     */
    void on_pushButton_pickup_clicked();

signals:
    //signal for go back to previous window
    void backsignal();

private:
    Ui::addresseewindow *ui;
    Manager* m;
};

#endif // ADDRESSEEWINDOW_H
