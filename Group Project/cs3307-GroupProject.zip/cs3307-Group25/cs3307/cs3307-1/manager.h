#ifndef MANAGER_H
#define MANAGER_H

#include <string>
#include "dropin.h"
#include "Locker.h"
#include "Message.h"
#include "Password.h"
#include "STime.h"
#include "administrator.h"
#include "driver.h"
#include "pickup.h"

/**
 * @author all teammates
 * @brief function for manmage all the lockers, and information of Administrators and Drivers
 *
 * @details Manager class is to achieve the function for locker, driver and admin. For locker, need to
 *  be open, check and set state. For Driver, need to log in the system and dropin parcels.
 * For Administrator, need to log in the system and modify the password.
 *
 *
 */
class Manager
{
public:
    /**
     * @brief initialize the Manager
     * @details read 3 files which include information of lockers, drivers and admins
     * , then initialize the private variable in the class
     */
    void init();

    /**
     * @brief driver dropin a parcel
     * @details driver want to drop in a parcel, then will open a empty locker and send
     * message to addressee with the locker id and password
     * @param a Dropin object which include addressee's name and phone number
     */
    std::string dropin(Dropin dropin);

    /**
     * @brief pick up a parcel
     * @details the function will open the locker if the locker id and password in the
     * input parameter is correct
     * @param a Pickup object which include locker id and password
     */
    bool pickup(Pickup pickup);

    /**
     * @brief get a empty locker
     * @details the function will check the locker array to find a empty locker, then
     * return it
     * @return return a Locker object point with is empty
     */
    Locker* getEmpty();

    /**
     * @brief open the locker by id
     * @details open the locker and then return ture if can open, otherwise return false
     * @param locker id
     * @return return ture if the locker can open, otherwise return false
     */
    bool open(int id);

    /**
     * @brief check a locker state
     * @details the function will return the state of the locker if exist
     * @param a locker id
     * @return the state name of locker
     */
    std::string check(int id);

    /**
     * @brief update the state of lockers which stored over 7 days
     * @details the function will check all the locker and if the locker have stored
     * over 7 days, then will change the state to expired
     * @return true if the operation finished, otherwise return false
     */
    std::string updateLocker();

    /**
     * @brief set the state by input
     * @details the fuction will change the locker state to the new state which in the
     * input
     * @param a locker id
     * @param a state name
     * @return true if change state success, otherwise false
     */
    bool setState(int id, std::string newstate);

    /**
     * @brief add a new driver
     * @details the function will add a new driver in the array by the input username
     * and password
     * @param username of driver
     * @param password of driver
     * @return true if add success, otherwise false
     */
    bool addDriver(std::string username, std::string pwd);

    /**
     * @brief delete a driver
     * @details the function will delete a new driver in the array by the input username
     * @param username of driver
     * @return true if delete success, otherwise false
     */
    bool deleteDriver(std::string username);

    /**
     * @brief chaneg the password of administator
     * @details the function will change the password of admin if the input old password
     * is correct
     * @param old password of admin
     * @param new password of admin
     * @return true if change success, otherwise false
     */
    bool changeAdminPwd(std::string oldpwd, std::string newpwd);

    /**
     * @brief a admin want to log in the system
     * @details the function will allow admin to log in the system if the username and
     * password are correct
     * @param username of admin
     * @param password of admin
     * @return true if login success, otherwise false
     */
    bool loginAdmin(std::string username, std::string pwd);

    /**
     * @brief a driver want to log in the system
     * @details the function will allow driver to log in the system if the username and
     * password are correct
     * @param username of driver
     * @param password of driver
     * @return true if login success, otherwise false
     */
    bool loginDriver(std::string username, std::string pwd);

private:
    Locker* listoflocker[20];
    int numOfLocker;
    Administrator admin;
    Driver* listOfDriver[20];
    int numOfDriver;
    /**
     * @brief print out the information of lockers
     * @details the function will print out the new information of all lockers
     */
    void printout_locker();

    /**
     * @brief print out the information of drivers
     * @details the function will print out the new information of all drivers
     */
    void printout_driver();

    /**
     * @brief print out the information of drivers
     * @details the function will print out the new information of all drivers
     */
    void printout_admin();

};

#endif // MANAGER_H
