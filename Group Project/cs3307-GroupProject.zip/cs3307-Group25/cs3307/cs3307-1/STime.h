#ifndef STIME_H_
#define STIME_H_

#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <time.h>
#include <chrono>
#include <ctime> 


/**
 * @author Jiayi Zhang
 * @brief This class is about time calculation.
 * @detials In this class, it will set the first storage time and calculate the storage time.
 * If the user do not pick up, the system will sent a warning message to the user for pick-up.
 */
class STime{
public:
	int starttime, storagetime;
	
   /**
    * @brief This function will return the total storage time.
    * @details In this function, it will return the total storage time.
    * @return storageTime
    */
	int getTime();
	
   /**
    * @brief This function will raise a warning if the storage time is bigger than 7.
    * @details In this function, it will get the storage time and compare it to 7. If the storage time
    * is bigger than 7, it will sent a message to the user.
    */
	void warning();
	
   /**
    * @brief This function will set the start time according to the present time.
    * @details In this function, it will get the present time and set the time to the start time.
    */
	void startTime();
    
    /**
     * @brief This function will set the first storage time.
     * @details In this function, it will get the present time and calculate the days.
     */
	void  setStorageTime();
    
    /**
     * @brief This function will return the start time.
     * @details In this function, it will return the satrt time.
     * @return startTime
    */
	int getStartTime();
    
   /**
    * @brief This function will set the specific start time.
    * @details In this function, from the user input, to get the specific start time. After get the start time,
    * this function will set the start time.
    */
    void setStartTime(int t);
};



#endif /* STIME_H_ */
