#ifndef ADMINWINDOW_DRIVER_ADD_H
#define ADMINWINDOW_DRIVER_ADD_H

#include <QDialog>
#include "manager.h"

namespace Ui {
class adminwindow_driver_add;
}

/**
 * @brief The admin add driver window
 * @author Yue Zhao
 */
class adminwindow_driver_add : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief admin log in window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit adminwindow_driver_add(QWidget *parent = nullptr, Manager* m = nullptr);
    ~adminwindow_driver_add();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a button for adding a driver
     */
    void on_pushButton_add_clicked();

signals:
    void backdriver();

private:
    Ui::adminwindow_driver_add *ui;
    Manager* m;
};

#endif // ADMINWINDOW_DRIVER_ADD_H
