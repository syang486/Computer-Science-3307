#ifndef LOCKER_STATE_H
#define LOCKER_STATE_H

#include <string>

/**
 * @brief A constructor class
 * A constructor class that initialize Locker State object
 *
 * @author Shulan Yang
 */
class LockerState;

/**
 * @brief A constructor class
 * A constructor class that initialize Locker State object
 */
class LockerState
{
public:
    
    /**
     * @brief A constructor method
     * A constructor method that initialize Locker State object
     */
    LockerState();
    
    /**
     * @brief An open method
     * A base method of opening the locker
     */
    virtual void open();
    
    /**
     * @brief A close method
     * A base method of closing the locker
     */
    virtual void close();
    
    /**
     * @brief An alarm method
     * A base method of alarming the manager
     */
    virtual void alarm();
    
    /**
     * @brief A store method
     * A base method of storing the parcel into the locker
     */
    virtual void store();
    
    /**
     * @brief A time recording method
     * A base method of recording time
     */
    virtual void timeRecord();
    
    /**
     * @brief A lock method
     * A base method of locking the locker
     */
    virtual void lock();
    
    /**
     * @brief A getting method
     * A base method of getting a state name
     * @return the state name string
     */
    virtual std::string getStateName();
    
};

#endif

