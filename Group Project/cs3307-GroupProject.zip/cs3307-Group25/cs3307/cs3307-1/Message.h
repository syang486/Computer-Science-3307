#ifndef MESSAGE_H_
#define MESSAGE_H_

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include "twilio.hh"

/**
 * @brief The Message class for send message to client
 * The Message class for send message to client by giving name , phone number
 * , locker id and password.
 * @author Yue Zhao
 */
class Message{

public:
    /**
     * @brief send Message to client
     * the function will take name , phone number
     * , locker id and password, then send the message by a format
     * @param addressee's name
     * @param addressee's phonenum
     * @param locker Id
     * @param password
     * @return true if send successful, otherwise return false
     */
    bool sendMessage(std::string name, std::string phonenum, int lockerId, int pwd);

};




#endif

