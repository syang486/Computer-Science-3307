#include "driver.h"

Driver::Driver()
{

}

void Driver::init(std::string username, std::string pwd){
    this->username = username;
    this->password = pwd;
}

std::string Driver::getUsername(){
    return this->username;
}

std::string Driver::getPassword(){
    return this->password;
}

void Driver::setPassword(std::string newpwd){
    this->password = newpwd;
}
