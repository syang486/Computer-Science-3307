#include "driverwindow_dropin.h"
#include "ui_driverwindow_dropin.h"
#include <QMessageBox>

driverwindow_dropin::driverwindow_dropin(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::driverwindow_dropin)
{
    ui->setupUi(this);
    this->setWindowTitle("Driver");
    this->m = m;
}

driverwindow_dropin::~driverwindow_dropin()
{
    delete ui;
}

void driverwindow_dropin::on_pushButton_back_clicked()
{
    emit backsignal();
    this->close();
}

void driverwindow_dropin::on_pushButton_dropin_clicked()
{
    QString name_s = ui->lineEdit_name->text();
    QString phonenum_s = ui->lineEdit_phonenum->text();
    std::string name = name_s.toUtf8().constData();
    std::string phonenum = phonenum_s.toUtf8().constData();
    Dropin d;
    d.init(name, phonenum);
    std::string dropin_return;
    dropin_return = this->m->dropin(d);
    if(dropin_return.compare("Invalid phone number") == 0){
        QMessageBox::warning(this, "Dropin", "Invalid phonenum");
    }
    else if(dropin_return.compare("No empty locker") == 0){
        QMessageBox::warning(this, "Dropin", "Invalid phonenum or No empty locker");
    }
    else{
        QString id = QString::fromStdString(dropin_return);
        QMessageBox::information(this, "Dropin", QString("Locker %1 opened.Please dropin the parcel").arg(id));
    }

}
