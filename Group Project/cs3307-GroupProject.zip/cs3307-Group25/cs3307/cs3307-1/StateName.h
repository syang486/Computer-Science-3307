#ifndef StateName_h
#define StateName_h

/**
 * @brief A construct method
 * A constructor method that create an enum called StateName
*/
enum StateName{
    empty, full, block, expired
};

#endif /* StateName_h */
