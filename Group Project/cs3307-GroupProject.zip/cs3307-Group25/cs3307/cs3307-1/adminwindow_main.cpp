#include "adminwindow_main.h"
#include "ui_adminwindow_main.h"
#include <QMessageBox>

adminwindow_main::adminwindow_main(QWidget *parent, Manager* m) :
    QDialog(parent),
    ui(new Ui::adminwindow_main)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrator");
    this->m = m;
}

adminwindow_main::~adminwindow_main()
{
    delete ui;
}

void adminwindow_main::reshow(){
    this->show();
}

void adminwindow_main::on_pushButton_back_clicked()
{
    emit backsignal();
    this->close();
}

void adminwindow_main::on_pushButton_change_state_clicked()
{
    changestate = new adminwindow_changestate(this, m);
    changestate->show();
    this->hide();
    connect(changestate, SIGNAL(backadmin()), this, SLOT(reshow()));
}

void adminwindow_main::on_pushButton_open_clicked()
{
    open = new adminwindow_open(this, m);
    open->show();
    this->hide();
    connect(open, SIGNAL(backadmin()), this, SLOT(reshow()));
}

void adminwindow_main::on_pushButton_admin_pwd_clicked()
{
    adminpwd = new adminwindow_adminpwd(this, m);
    adminpwd->show();
    this->hide();
    connect(adminpwd, SIGNAL(backadmin()), this, SLOT(reshow()));
}

void adminwindow_main::on_pushButton_driver_clicked()
{
    driver = new adminwindow_driver(this, m);
    driver->show();
    this->hide();
    connect(driver, SIGNAL(backadmin()), this, SLOT(reshow()));
}

void adminwindow_main::on_pushButton_update_clicked()
{
    std::string warning = this->m->updateLocker();
    QString warn = QString::fromStdString(warning);
    if(warning.compare("") == 0){
        QMessageBox::information(this, "Update State", "No locker warning");
    }
    else{
        QMessageBox::warning(this, "Warning", QString("Locker Warning:%1").arg(warn));
    }
}

void adminwindow_main::on_pushButton_check_clicked()
{
    check = new adminwindow_checkstate(this, m);
    check->show();
    this->hide();
    connect(check, SIGNAL(backadmin()), this, SLOT(reshow()));
}
