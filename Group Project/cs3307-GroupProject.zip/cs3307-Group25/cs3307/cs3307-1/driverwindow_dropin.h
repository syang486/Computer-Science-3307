#ifndef DRIVERWINDOW_DROPIN_H
#define DRIVERWINDOW_DROPIN_H

#include <QDialog>
#include "manager.h"

namespace Ui {
class driverwindow_dropin;
}

/**
 * @brief The driver main window
 * @author Yue Zhao
 */
class driverwindow_dropin : public QDialog
{
    Q_OBJECT

public:
    /**
     * @brief driver main window constructor
     * @param parent
     * @param the Manager object pointer
     */
    explicit driverwindow_dropin(QWidget *parent = nullptr, Manager* m = nullptr);
    ~driverwindow_dropin();

private slots:
    /**
     * @brief a button for going to the previous windowß
     */
    void on_pushButton_back_clicked();

    /**
     * @brief a botton for drop in a parcel
     * a locker will open if the input correct and exist a empty locker
     */
    void on_pushButton_dropin_clicked();

signals:
    void backsignal();

private:
    Ui::driverwindow_dropin *ui;
    Manager* m;
};

#endif // DRIVERWINDOW_DROPIN_H
