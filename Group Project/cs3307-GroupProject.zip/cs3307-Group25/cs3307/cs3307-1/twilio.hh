#pragma once

#include <string>
#include "type_conversion.hh"

namespace twilio {

/**
 * @brief The Twilio class from SMS api on website
 */
class Twilio {
public:
        Twilio(std::string const& account_sid_in, 
               std::string const& auth_token_in)
                : account_sid(account_sid_in)
                , auth_token(auth_token_in)
        {}
        // Nothing in destructor
        ~Twilio() = default;
        /**
         * @brief send message to addressee
         * @param phone number send to
         * @param phone number from
         * @param message body
         * @param response
         * @param picture url
         * @param verbose
         * @return
         */
        bool send_message(
                std::string const& to_number,
                std::string const& from_number,
                std::string const& message_body,
                std::string& response,
                std::string const& picture_url = "",
                bool verbose = false
        );

private:

        // Used for the username of the auth header
        std::string const account_sid;
        // Used for the password of the auth header
        std::string const auth_token;

        // Portably ignore curl response
        static size_t _null_write(char *, size_t, size_t, void *);
        // Write curl response to a stringstream
        static size_t _stream_write(char *, size_t, size_t, void *);
};

} // end namespace twilio
