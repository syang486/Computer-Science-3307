#ifndef LOCKER_H
#define LOCKER_H

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "StateFactory.h"

/**
 * @brief This is a header file for Locker class
 * @author Meihong Quan
 */
class Locker{

private:
    //Attributes
    int lockerID;
    int lockerPassword;
    LockerState* state;
    int startTime;

public:
   /**
    * @brief Constructor function
    * @details This function is a constructor for this locker object class that contains several attributes:
    *the locker id, locker password, locker state, (locker state factory for create locker state) and the storing start time of the locker
    * @param i is an integer type locker id variable
    * @param pwd is an integer type locker password variable
    * @param state is a string type locker state variable
    * @param t is the integer storing start time of the locker
    */
    void init(int i, int pwd, std::string state, int t);
    
   /**
    * @brief Set locker state by given input
    * @details This function allows the user to change locker state to the new state
    * @param Lstate is a string type locker state that will be set to the locker
    */
    void setLockerState(std::string Lstate);
    
   /**
    * @brief Locker state get function
    * @details This function gives the user the current locker state
    * @return state which is the current locker state
    */
    LockerState* getLockerState();
    
   /**
    * @brief Set locker ID by given input
    * @details This function allows the user to change the locker id to the new id
    * @param lockerId is an integer type locker id that will be set to the locker
    */
    void setLockerID(int lockerId);
    
   /**
    * @brief Locker ID get function
    * @details This function gives the user the locker id
    * @return lockerID which is its current locker id
    */
    int getLockerID();
    
   /**
    * @brief Set Locker password by given input
    * @details This function allows the user to change the locker password to the new password
    * @param lockerp which is an integer type locker password that will be set to the locker
    */
    void setLockerPassword(int locerp);
    
   /**
    * @brief Locker password get function
    * @details This function gives its locker password
    * @return lockerPassword is its current locker password
    */
    int getLockerPassword();
    
   /**
    * @brief Set locker storing start time by given input
    * @details This function allows to update the storing start time of the locker
    * @param t which is an integer type start time that will be set to the locker
    */
    void setStartTime(int t);
    
   /**
    * @brief Storing start time get function
    * @details This function gives the storing start time of the locker
    * @return startTime which is the storing start time of the current locker
    */
    int getStartTime();
    
   /**
    * @brief A print function that will output a "locker opened" sentence
    * @details This function prints a sentence telling the user that the locker has been opened
    */
    void openByManager();
};

#endif
