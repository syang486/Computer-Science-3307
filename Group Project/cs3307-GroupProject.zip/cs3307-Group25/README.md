CS3307-Group 25

Project: Courier cabinet system

For build and run the program:
The program was developed on Qt creator. If want to build that, using Qt creator and open the .pro in the
dirctory. 

Before build that, one more thing need to check:
In manager.cpp file, need to change the file pathe of locker.txt, driver.txt and admin.txt. Make sure using the correct file path. There will be 6 points need to be changed where 3 in init(), 1 in printout_admin(), 1 in printout_driver, and 1 in printout_locker().

If create a new project and use our file as soure file:
Make sure include 

LIBS += -lcurl

this line of code need to be added aftet:

TARGET = $ your project name 
TEMPLATE = app

it should be like:
TARGET = $ your project name 
TEMPLATE = app
LIBS += -lcurl

For the send message function:
Using the Twilio API, and did not pay for the account. Thus the function only can send message to 6479668027 which is a phone number of one group member.
