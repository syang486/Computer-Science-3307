var searchData=
[
  ['mainwindow_46',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['manager_47',['Manager',['../class_manager.html',1,'']]],
  ['message_48',['Message',['../class_message.html',1,'']]]
];
