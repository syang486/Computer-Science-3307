var searchData=
[
  ['mainwindow_111',['MainWindow',['../class_main_window.html',1,'']]],
  ['manager_112',['Manager',['../class_manager.html',1,'']]],
  ['message_113',['Message',['../class_message.html',1,'']]]
];
