var indexSectionsWithContent =
{
  0: "abcdefgilmoprstuw",
  1: "abdeflmpst",
  2: "abcdefgilmoprstuw",
  3: "lp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

